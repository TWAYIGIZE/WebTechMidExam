package model;

public enum RoleType {
	STUDENT, MANAGER, TEACHER, DEAN, HOD, LIBRARIAN
}
